import os 
import sys
from zipfile import ZipFile

if sys.platform in ('win32', 'cygwin'):
    pythonPath = os.path.dirname(sys.executable)
    site_packages = os.path.join(pythonPath,"Lib/site-packages")
elif sys.platform in ("linux","linux2"):
    for i in os.listdir(os.path.expanduser("~/.local/lib/")):
        if "python3" in i:
            if "site-packages" in os.listdir(i):
                site_packages = os.path.join(os.path.expanduser("~/.local/lib/"),i,"site-packages")  
        else:
            print("Sorry, Python is either not installed or is outdated!")
with ZipFile("components/margray_2d.zip") as zip_file:
    zip_file.extractall(site_packages)
    print("Successfully Installed margray_2d to", site_packages.replace("\\","/"))